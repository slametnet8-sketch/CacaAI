package com.cacaai.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var output: TextView
    private lateinit var input: EditText
    private var recognizer: SpeechRecognizer? = null
    private val requestAudio = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(0xFFFFF4FA.toInt())
        }

        val title = TextView(this).apply {
            text = "CACA AI"
            textSize = 30f
            setTextColor(0xFFB83F83.toInt())
            gravity = Gravity.CENTER
        }
        val robot = TextView(this).apply {
            text = "🤖"
            textSize = 86f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 8)
        }
        val subtitle = TextView(this).apply {
            text = "Halo, Bos! Aku Caca. Ada yang bisa kubantu?"
            textSize = 18f
            setTextColor(0xFF653B55.toInt())
            gravity = Gravity.CENTER
        }
        output = TextView(this).apply {
            text = "Caca siap mendengarkan."
            textSize = 16f
            setTextColor(0xFF4B3543.toInt())
            setPadding(12, 24, 12, 24)
            gravity = Gravity.CENTER
        }
        input = EditText(this).apply {
            hint = "Tulis pesan untuk Caca..."
            textSize = 16f
            setSingleLine(false)
        }
        val send = Button(this).apply {
            text = "Kirim"
            setOnClickListener { handleMessage(input.text.toString()) }
        }
        val mic = Button(this).apply {
            text = "🎤 Bicara dengan Caca"
            setOnClickListener { startListening() }
        }
        val note = TextView(this).apply {
            text = "Versi awal: Caca sudah bisa mendengar suara dan membalas dengan suara. Sambungan otak AI online perlu dikonfigurasi berikutnya."
            textSize = 12f
            setTextColor(0xFF8A7180.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 0)
        }

        root.addView(title, match())
        root.addView(robot, match())
        root.addView(subtitle, match())
        root.addView(output, match())
        root.addView(input, LinearLayout.LayoutParams(-1, 100))
        root.addView(send, match())
        root.addView(mic, match())
        root.addView(note, match())
        setContentView(root)
    }

    private fun match() = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("id", "ID")
            tts.setSpeechRate(0.94f)
        }
    }

    private fun say(text: String) {
        output.text = text
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "caca_reply")
    }

    private fun handleMessage(raw: String) {
        val msg = raw.trim()
        if (msg.isEmpty()) return
        input.setText("")
        val lower = msg.lowercase(Locale("id", "ID"))
        when {
            lower.contains("buka youtube") -> openApp("com.google.android.youtube", "YouTube")
            lower.contains("buka whatsapp") || lower.contains("buka wa") -> openApp("com.whatsapp", "WhatsApp")
            lower.contains("buka kamera") -> {
                try {
                    startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                    say("Baik, Bos. Aku buka kamera.")
                } catch (_: Exception) { say("Maaf, kamera tidak bisa dibuka.") }
            }
            lower.contains("halo") || lower.contains("hai") -> say("Halo juga, Bos! Caca siap menemani.")
            lower.contains("nama kamu") -> say("Namaku Caca, asisten pribadi Bos.")
            lower.contains("terima kasih") -> say("Sama-sama, Bos. Senang bisa membantu.")
            else -> say("Aku sudah menerima pesan Bos: $msg. Untuk menjawab bebas dengan kecerdasan AI online, sambungan layanan AI perlu diaktifkan pada tahap berikutnya.")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            say("Baik, Bos. Aku buka $label.")
        } else say("$label belum terpasang di HP ini.")
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Fitur pengenal suara tidak tersedia di HP ini.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { output.text = "Caca mendengarkan..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { output.text = "Belum terdengar jelas. Coba bicara lagi, Bos." }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    input.setText(spoken)
                    handleMessage(spoken)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Bicara dengan Caca")
        }
        recognizer?.startListening(intent)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
