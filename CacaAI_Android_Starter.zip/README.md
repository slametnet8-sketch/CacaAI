# Caca AI — starter Android project

Starter aplikasi Android untuk robot asisten virtual Caca, dengan tema putih-pink, suara TTS Bahasa Indonesia, pengenalan suara, dan beberapa perintah lokal sederhana.

## Yang sudah ada
- Layar awal Caca.
- Tombol mikrofon untuk mengenali ucapan Bahasa Indonesia (memerlukan layanan speech recognition di perangkat).
- Caca membalas dengan Text-to-Speech Bahasa Indonesia.
- Perintah sederhana: buka YouTube, WhatsApp, kamera; sapaan; dan nama Caca.

## Yang belum ada
- Otak AI online belum disambungkan. Jangan menaruh API key rahasia langsung di aplikasi Android. Untuk AI online, tahap berikutnya perlu backend/proxy yang aman dan konfigurasi layanan AI.
- Karakter 3D bergerak masih berupa placeholder emoji; model 3D dan animasi perlu ditambahkan.
- Fitur pengingat/alarm belum diimplementasikan.

## Cara build APK
1. Buka proyek ini di Android Studio pada komputer.
2. Tunggu Gradle Sync selesai (gunakan JDK 17).
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.
5. Pindahkan APK ke HP Android dan izinkan pemasangan dari sumber tersebut jika diminta.

Target minimum Android 6.0 (API 23); target SDK 32 untuk kompatibilitas awal.
